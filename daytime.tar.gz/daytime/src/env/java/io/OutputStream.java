/* $Id: OutputStream.java 276 2006-01-17 03:32:37Z cartho $ */

package env.java.io;

/* Stub class for OutputStream (just a /dev/null). */

import java.io.IOException;

public class OutputStream extends java.io.OutputStream {
  public OutputStream() {
  }

  public void write(int b) throws IOException {
  }

  public void write(byte[] b) throws IOException {
  }
}
