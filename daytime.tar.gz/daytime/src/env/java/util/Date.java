/* $Id: Date.java 834 2010-11-24 07:28:51Z cartho $ */

package env.java.util;

/* Stub class for java.util.Date. */

public class Date {
  public Date() {
  }

  public String toString() {
    return "Tue Jan 17 11:31:39 JST 2011";
  }
}
