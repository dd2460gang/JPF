/* $Id: InetSocketAddress.java 272 2006-01-17 02:20:25Z cartho $ */

package env.java.net;

/* Stub for java.net.InetSocketAddress. */

public class InetSocketAddress {
  public InetSocketAddress(String hostname, int port) { }
}
